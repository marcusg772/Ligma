UPLOAD INSTRUCTIONS:
1. On your iPhone, download the zip file from this link (provided after creation).
2. Open the Files app and locate the downloaded zip (Usually in 'Downloads' or 'On My iPhone/Downloads').
3. Tap the zip to unzip it. You should see `index.html` and `icon.png`.
4. In Safari, go to https://github.com and open your repository.
5. Tap "Add file" -> "Upload files", choose `index.html` and `icon.png` from Files and upload them to your repo root.
6. In the repo Settings -> Pages, ensure branch 'main' and folder '/' (root) are selected, then Save.
7. Open the published GitHub Pages URL (https://yourusername.github.io/your-repo-name/) in Safari.
8. Tap Share -> Add to Home Screen to install the web app on your iPhone.
